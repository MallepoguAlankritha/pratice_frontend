import googleLogo from "./googleLogo.png";

export { googleLogo };
